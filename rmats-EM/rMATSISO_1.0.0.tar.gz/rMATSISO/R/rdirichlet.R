#' Sample from the dirichlet distribution
#'
#' Used internally by rMATSISO. This function draws a sample from the
#' dirichlet distribution
#'
#' @param n Positive integer > 0. Number of samples to draw.
#' @param alpha Vector with positive entries. Dirichlet parameter vector.
#' @return The function rdirichlet returns the following:
#' \item{X}{Matrix with n rows and length(alpha) columns. Each row is one draw from dirichlet(alpha).}
#' @export

rdirichlet <- function(n, alpha){

  k   <- length(alpha)
  z   <- matrix(rgamma(k * n, alpha), ncol = k, byrow = TRUE)
  den <- z %*% rep(1, k)
  z/as.vector(den)

}
