#' Negative E-step of EM algorithm
#'
#' Used internally by rMATSISO. Function for computing the negative E step of
#' the EM algorithm for the unconstrained model
#'
#' @param x Parameter vector for Dirichlet distribution. This contains group 1 and group 2 parameters in 1 vector.
#' @param nIsoforms Positive integer > 0. The number of valid isoforms in this ASM.
#' @param psi.tilde1 Expected psi matrix for group 1.
#' @param psi.tilde2 Expected psi matrix for group 2.
#' @param n1 Sample size for this ASM in group 1.
#' @param n2 Sample size for this ASM in group 2.
#' @param num_groups Number of sample groups (1 or 2).
#' @return The function ll_EM returns the following:
#' \item{y}{Value of log-likelihood of unconstrained model}
#' @export
#'

ll_EM <- function(x, nIsoforms, psi.tilde1, psi.tilde2 = NULL, n1, n2 = NULL, num_groups){

  a1 <- 0
  a2 <- 0
  a3 <- 0
  a4 <- 0

  a1 <- -n1 * sum(lgamma(x[1:nIsoforms])) + n1 * lgamma(sum(x[1:nIsoforms]))
  a3 <- sum(psi.tilde1 %*% x[1:nIsoforms])

  if(num_groups == 2){
    a2 <- -n2 * sum(lgamma(x[(nIsoforms+1):(2*nIsoforms)])) + n2 * lgamma(sum(x[(nIsoforms+1):(2*nIsoforms)]))
    a4 <- sum(psi.tilde2 %*% x[(nIsoforms+1):(2*nIsoforms)])
  }

  -(a1 + a2 + a3 + a4)

}
