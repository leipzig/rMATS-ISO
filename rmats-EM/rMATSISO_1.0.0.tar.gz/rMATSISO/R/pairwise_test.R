#' Pairwise test for rMATS-Iso
#'
#' This function tests each pair of isoforms between
#' both groups to see where there are any differences in
#' isoform inclusion levels
#'
#' @param nIsoforms: Vector of number of isoforms for each ASM.
#' @param K1: Number of replicates in group 1.
#' @param K2: Number of replicates in group 2.
#' @param alpha.c: MLE estimate under null hypothesis of no group difference.
#' @param isof_incl_u1: Vector of isoform inclusion rates for group 1 (unconstrained MLE).
#' @param isof_incl_u2: Vector of isoform inclusion rates for group 2 (unconstrained MLE).
#' @param num_Sim: Number of simulations to perform. Default value of 1e+05.
#' @return The function pairwise_test tests each pair of isoform for a pairwise difference.
#' \item{isoform_pvals}{Vector of p values for each pairwise isoform test.}
#' @export
#'

pairwise_test <- function(nIsoforms, K1, K2, alpha.c, isof_incl_u1, isof_incl_u2, num_Sim = 1e+05){

  isof_incl_u1_sim <- matrix(0, nrow = num_Sim, ncol = nIsoforms)
  isof_incl_u2_sim <- matrix(0, nrow = num_Sim, ncol = nIsoforms)
  for(t in 1:num_Sim){

    ## Draw psi's from 2 groups from constrained model
    psi_1_sim <- rdirichlet(K1, alpha.c)
    psi_2_sim <- rdirichlet(K2, alpha.c)

    ## Compute sample means for both groups
    isof_incl_u1_sim[t,] <- colMeans(psi_1_sim)
    isof_incl_u2_sim[t,] <- colMeans(psi_2_sim)

  }

  isoform_pvals <- rep(0, nIsoforms)
  for(j in 1:nIsoforms){

    ## Actual difference we saw in our data (unconstrained)
    obs_diff <- isof_incl_u1[j] - isof_incl_u2[j]

    ## Histogram of alpha_1_sim - alpha_2_sim
    sim_diff <- isof_incl_u1_sim[,j] - isof_incl_u2_sim[,j]
    p_val    <- mean(sim_diff >= abs(obs_diff)) + mean(sim_diff <= -abs(obs_diff))

    ## Save p-value
    isoform_pvals[j] <- p_val

  }

  isoform_pvals

}

