#' Gradient of negative E-step of EM algorithm
#'
#' Used internally by rMATSISO. Function for computing the gradient of the negative E step of
#' the EM algorithm for the unconstrained model
#'
#' @param x Parameter vector for Dirichlet distribution. This contains group 1 and group 2 parameters in 1 vector.
#' @param nIsoforms Positive integer > 0. The number of valid isoforms in this ASM.
#' @param psi.tilde1 Expected psi matrix for group 1.
#' @param psi.tilde2 Expected psi matrix for group 2.
#' @param n1 Sample size for this ASM in group 1.
#' @param n2 Sample size for this ASM in group 2.
#' @param num_groups Number of sample groups (1 or 2).
#' @return The function ll_EM_gr returns the following:
#' \item{y}{Value of the gradient of the negative E step of the unconstrained model}
#' @export
#'

## Gradient of negative E step
ll_EM_gr <- function(x, nIsoforms, psi.tilde1, psi.tilde2 = NULL, n1, n2 = NULL, num_groups){

  a1 <- 0
  a2 <- 0
  a3 <- 0
  a4 <- 0

  a1 <- -n1 * (digamma(x[1:nIsoforms]) - digamma(sum(x[1:nIsoforms])))
  a3 <- colSums(psi.tilde1)

  if(num_groups == 2){
    a2 <- -n2 * (digamma(x[(nIsoforms+1):(2*nIsoforms)]) - digamma(sum(x[(nIsoforms+1):(2*nIsoforms)])))
    a4 <- colSums(psi.tilde2)
  }

  if(num_groups == 2){
    -c(a1 + a3, a2 + a4)
  }else{
    -(a1 + a3)
  }

}
