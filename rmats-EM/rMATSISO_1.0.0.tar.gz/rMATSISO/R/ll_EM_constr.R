#' Negative E-step of EM algorithm
#'
#' Used internally by rMATSISO. Function for computing the negative E step of
#' the EM algorithm for the constrained model
#'
#' @param x Parameter vector for Dirichlet distribution. This contains group 1 and group 2 parameters in 1 vector.
#' @param psi.tilde1 Expected psi matrix for group 1.
#' @param psi.tilde2 Expected psi matrix for group 2.
#' @param n1 Sample size for this ASM in group 1.
#' @param n2 Sample size for this ASM in group 2.
#' @return The function ll_EM_constr returns the following:
#' \item{y}{Value of log-likelihood of constrained model}
#' @export
#'

ll_EM_constr <- function(x, psi.tilde1, psi.tilde2, n1, n2){

  a1 <- -n1 * sum(lgamma(x)) + n1 * lgamma(sum(x))
  a2 <- -n2 * sum(lgamma(x)) + n2 * lgamma(sum(x))
  a3 <- sum(psi.tilde1 %*% x)
  a4 <- sum(psi.tilde2 %*% x)

  -(a1 + a2 + a3 + a4)

}
