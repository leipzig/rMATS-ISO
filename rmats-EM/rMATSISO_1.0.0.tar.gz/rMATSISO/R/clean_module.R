#' Clean the given alternative splicing module and tag invalid cases
#'
#' This function is used internally by rMATSISO to filter away invalid
#' reads and tag an ASM as being invalid (e.g. no reads available in either
#' sample group).
#'
#' @param num_groups: Number of sample groups (1 or 2).
#' @param Y1_ASM_raw: List of read counts for group 1.
#' @param Y2_ASM_raw: List of read counts for group 2. If num_groups = 1, set this to NULL.
#' @param pseudo_left_ind: Length of left pseudo-exon.
#' @param pseudo_right_ind: Length of right pseudo-exon.
#' @param isoStruct_ind: Exon and isoform structure. Part of the output of prepare_data.R.
#' @param readLengths1_ind: A vector containing the unique read lengths for this ASM in group 1.
#' @param readLengths2_ind: A vector containing the unique read lengths for this ASM in group 2. If num_groups = 1, set this to NULL.
#' @param nIsoforms_ind: Number of isoforms in this ASM.
#' @param nExons_ind: Number of exons in this ASM.
#' @param n1: Number of replicates in group 1.
#' @param n2: Number of replicates in group 2. If num_groups = 1, set this to NULL.
#' @return The function clean_module returns a list containing the elements listed below:
#' \item{Y1_ASM}{List of read counts for group 1.}
#' \item{Y2_ASM}{List of read counts for group 2. If num_groups = 1, this is not returned.}
#' \item{K1}{Number of replicates in group 1.}
#' \item{K2}{Number of replicates in group 2. If num_groups = 1, this is not returned.}
#' \item{eff_len_g1}{Matrix containing the effective lengths of each isoform for the reads in sample group 1.}
#' \item{eff_len_g2}{Matrix containing the effective lengths of each isoform for the reads in sample group 2. If num_groups = 1, this is not returned.}
#' \item{thetaNonzero1}{List of pattern consistency matrices for each read length in group 1.}
#' \item{thetaNonzero2}{List of pattern consistency matrices for each read length in group 2. If num_groups = 1, this is not returned.}
#' \item{rUnique1}{A vector containing the unique read lengths for this ASM in group 1.}
#' \item{rUnique2}{A vector containing the unique read lengths for this ASM in group 2. If num_groups = 1, this is not returned.}
#' \item{r1}{Number of unique read lengths in group 1.}
#' \item{r2}{Number of unique read lengths in group 2. If num_groups = 1, this is not returned.}
#' \item{nIsoforms}{Number of isoforms in this module.}
#' \item{redundantTag}{Binary vector indicating which isoforms were tagged as being redundant.}
#' \item{merge_info}{Either "NA", or vector of strings indicating which isoforms have been merged into other isoforms.}
#' @export
#'
clean_module <- function(num_groups, Y1_ASM_raw, Y2_ASM_raw, pseudo_left_ind, pseudo_right_ind,
                         isoStruct_ind, readLengths1_ind, readLengths2_ind,
                         nIsoforms_ind, nExons_ind, n1, n2){

  #################################################################
  ## Generate the consistency probabilities and tag invalid ASMs ##
  #################################################################

  Y1_ASM <- Y1_ASM_raw
  if(length(Y1_ASM) == 0)
    return(NA)

  ## Filter away redundant isoforms (if there are any)
  filtered_results <- clean_redundancy(isoStruct_ind, nIsoforms_ind)

  ## If there is only 1 valid isoform, stop
  if(is.na(filtered_results))
    return(NA)

  isoStruct_new    <- filtered_results$isoStruct
  nIsoforms_new    <- filtered_results$nIsoforms
  redundantTag     <- filtered_results$redundantTag
  merge_info       <- filtered_results$merge_info

  Y1_ASM_new        <- Y1_ASM
  names(Y1_ASM_new) <- names(Y1_ASM)
  if(sum(redundantTag) > 0){

    ## Pattern matrix original vs filtered
    P_orig          <- pattern_grid(nIsoforms_ind)
    P_filt          <- pattern_grid(nIsoforms_new)
    valid_cols      <- which(redundantTag == 0)
    pattern_convert <- apply(P_orig[,valid_cols], 1, function(y) apply(P_filt, 1, function(x) identical(as.vector(x), as.vector(y))))

    ## Convert counts from old pattern to new pattern
    Y1_ASM_new <- list()
    rUnique1   <- sort(unique(readLengths1_ind))
    r1         <- length(rUnique1)
    for(rIndex in 1:r1){
      y1_current <- Y1_ASM[[rIndex]]
      y1_new     <- matrix(0, nrow = nrow(y1_current), ncol = nrow(P_filt))

      ## Run through new patterns
      for(pattern in 1:nrow(P_filt)){
        cur_pattern_cols <- which(pattern_convert[pattern,])
        if(nrow(y1_current) == 1){
          y1_new[,pattern] <- sum(y1_current[,cur_pattern_cols])
        }else{
          y1_new[,pattern] <- rowSums(y1_current[,cur_pattern_cols])
        }
      }

      Y1_ASM_new[[rIndex]] <- y1_new

    }
    names(Y1_ASM_new) <- names(Y1_ASM)

  }

  pseudo_left_ind  <- pseudo_left_ind
  pseudo_right_ind <- pseudo_right_ind
  num_pseudo       <- 1 * (pseudo_left_ind > 0) + 1 * (pseudo_right_ind > 0)
  cur.data         <- isoStruct_new

  ## Compute theta probabilities for group 1
  rUnique1      <- sort(unique(readLengths1_ind))
  r1            <- length(rUnique1)
  thetaNonzero1 <- list()
  for(rIndex in 1:r1){

    ## Adjust pseudo-exon lengths based on current read length
    cur.data.tmp  <- cur.data

    ## Add columns to exon structure if there are pseudoexons
    if(pseudo_left_ind > 0){
      cur.data.tmp$Fmatrix     <- cbind(1, cur.data.tmp$Fmatrix)
      cur.data.tmp$exonLengths <- c(min(rUnique1[rIndex], pseudo_left_ind), cur.data.tmp$exonLengths)
    }
    if(pseudo_right_ind > 0){
      cur.data.tmp$Fmatrix     <- cbind(cur.data.tmp$Fmatrix, 1)
      cur.data.tmp$exonLengths <- c(cur.data.tmp$exonLengths, min(rUnique1[rIndex], pseudo_right_ind))
    }

    ## Compute pattern normalization matrix
    theta <- normalize(nIsoforms_new, nExons_ind + num_pseudo, rUnique1[rIndex], cur.data.tmp)$theta

    ## Impossible for an isoform to have generated read given lengths
    if(any(is.na(colSums(theta))))
      return(NA)

    ## Exon structure is incompatible with read lengths
    if(sum(colSums(theta)) == 0)
      return(NA)

    ## Exon structure is incompatible with read lengths
    if(sum(colSums(theta)) != ncol(theta))
      return(NA)

    thetaNonzero1[[rIndex]] <- theta[(rowSums(theta) != 0), ]
    Y1_ASM_new[[rIndex]]        <- Y1_ASM_new[[rIndex]][,which((rowSums(theta) != 0))]
    if(class(Y1_ASM_new[[rIndex]]) == "numeric")
      Y1_ASM_new[[rIndex]] <- t(as.matrix(Y1_ASM_new[[rIndex]]))
  }
  names(thetaNonzero1) <- rUnique1

  ## Compute effective lengths for each read length
  eff_len_g1 <- matrix(0, nrow = r1, ncol = nIsoforms_new)
  for(rIndex in 1:r1){

    cur.data.tmp  <- cur.data

    ## Add columns to exon structure if there are pseudoexons
    if(pseudo_left_ind > 0){
      cur.data.tmp$Fmatrix     <- cbind(1, cur.data.tmp$Fmatrix)
      cur.data.tmp$exonLengths <- c(min(rUnique1[rIndex], pseudo_left_ind), cur.data.tmp$exonLengths)
    }
    if(pseudo_right_ind > 0){
      cur.data.tmp$Fmatrix     <- cbind(cur.data.tmp$Fmatrix, 1)
      cur.data.tmp$exonLengths <- c(cur.data.tmp$exonLengths, min(rUnique1[rIndex], pseudo_right_ind))
    }

    ## Compute effective lengths for each isoform
    eff_len_g1[rIndex,] <- as.vector(cur.data.tmp$Fmatrix %*% cur.data.tmp$exonLengths) - rUnique1[rIndex] + 1

  }

  ## Adjust Y1 and Y2 for differing numbers of replicates
  for(rIndex in 1:r1){
    K1 <- nrow(Y1_ASM_new[[rIndex]])
    if(K1 != n1){
      Y1_ASM_new[[rIndex]] <- rbind(Y1_ASM_new[[rIndex]], matrix(0, n1 - K1, ncol(Y1_ASM_new[[rIndex]])))
    }
  }

  ## Proceed if there is a second group
  if(num_groups == 2){

    Y2_ASM        <- Y2_ASM_raw
    if(length(Y2_ASM) == 0)
      return(NA)

    Y2_ASM_new        <- Y2_ASM
    names(Y2_ASM_new) <- names(Y2_ASM)
    if(sum(redundantTag) > 0){

      ## Convert counts from old pattern to new pattern
      Y2_ASM     <- Y2_ASM_raw
      Y2_ASM_new <- list()
      rUnique2   <- sort(unique(readLengths2_ind))
      r2         <- length(rUnique2)
      for(rIndex in 1:r2){
        y2_current <- Y2_ASM[[rIndex]]
        y2_new     <- matrix(0, nrow = nrow(y2_current), ncol = nrow(P_filt))

        ## Run through new patterns
        for(pattern in 1:nrow(P_filt)){
          cur_pattern_cols <- which(pattern_convert[pattern,])
          if(nrow(y2_current) == 1){
            y2_new[,pattern] <- sum(y2_current[,cur_pattern_cols])
          }else{
            y2_new[,pattern] <- rowSums(y2_current[,cur_pattern_cols])
          }
        }

        Y2_ASM_new[[rIndex]] <- y2_new

      }
      names(Y2_ASM_new) <- names(Y2_ASM)

    }

    ## Compute theta probabilities for group 2
    rUnique2      <- sort(unique(readLengths2_ind))
    r2            <- length(rUnique2)
    thetaNonzero2 <- list()
    for(rIndex in 1:r2){

      ## Adjust pseudo-exon lengths based on current read length
      cur.data.tmp  <- cur.data

      ## Add columns to exon structure if there are pseudoexons
      if(pseudo_left_ind > 0){
        cur.data.tmp$Fmatrix     <- cbind(1, cur.data.tmp$Fmatrix)
        cur.data.tmp$exonLengths <- c(min(rUnique2[rIndex], pseudo_left_ind), cur.data.tmp$exonLengths)
      }
      if(pseudo_right_ind > 0){
        cur.data.tmp$Fmatrix     <- cbind(cur.data.tmp$Fmatrix, 1)
        cur.data.tmp$exonLengths <- c(cur.data.tmp$exonLengths, min(rUnique2[rIndex], pseudo_right_ind))
      }

      ## Compute pattern normalization matrix
      theta <- normalize(nIsoforms_new, nExons_ind + num_pseudo, rUnique2[rIndex], cur.data.tmp)$theta

      ## Impossible for an isoform to have generated read given lengths
      if(any(is.na(colSums(theta))))
        return(NA)

      ## Exon structure is incompatible with read lengths
      if(sum(colSums(theta)) == 0)
        return(NA)

      thetaNonzero2[[rIndex]] <- theta[(rowSums(theta) != 0), ]
      Y2_ASM_new[[rIndex]]        <- Y2_ASM_new[[rIndex]][,(rowSums(theta) != 0)]
      if(class(Y2_ASM_new[[rIndex]]) == "numeric")
        Y2_ASM_new[[rIndex]] <- t(as.matrix(Y2_ASM_new[[rIndex]]))
    }
    names(thetaNonzero2) <- rUnique2

    eff_len_g2 <- matrix(0, nrow = r2, ncol = nIsoforms_new)
    for(rIndex in 1:r2){

      ## Adjust for pseudoexons
      cur.data.tmp  <- cur.data

      ## Add columns to exon structure if there are pseudoexons
      if(pseudo_left_ind > 0){
        cur.data.tmp$Fmatrix     <- cbind(1, cur.data.tmp$Fmatrix)
        cur.data.tmp$exonLengths <- c(min(rUnique2[rIndex], pseudo_left_ind), cur.data.tmp$exonLengths)
      }
      if(pseudo_right_ind > 0){
        cur.data.tmp$Fmatrix     <- cbind(cur.data.tmp$Fmatrix, 1)
        cur.data.tmp$exonLengths <- c(cur.data.tmp$exonLengths, min(rUnique2[rIndex], pseudo_right_ind))
      }
      ## Compute effective lengths for each isoform
      eff_len_g2[rIndex,] <- as.vector(cur.data.tmp$Fmatrix %*% cur.data.tmp$exonLengths) - rUnique2[rIndex] + 1

    }

    for(rIndex in 1:r2){
      K2 <- nrow(Y2_ASM_new[[rIndex]])
      if(K2 != n2){
        Y2_ASM_new[[rIndex]] <- rbind(Y2_ASM_new[[rIndex]], matrix(0, n2 - K2, ncol(Y2_ASM_new[[rIndex]])))
      }
    }

    ## Organize results into a list
    results <- list(Y1_ASM = Y1_ASM_new,
                    Y2_ASM = Y2_ASM_new,
                    K1 = K1,
                    K2 = K2,
                    eff_len_g1 = eff_len_g1,
                    eff_len_g2 = eff_len_g2,
                    thetaNonzero1 = thetaNonzero1,
                    thetaNonzero2 = thetaNonzero2,
                    rUnique1 = rUnique1,
                    rUnique2 = rUnique2,
                    r1 = r1,
                    r2 = r2,
                    nIsoforms = nIsoforms_new,
                    redundantTag = redundantTag,
                    merge_info = merge_info)

  }else{

    ## Organize results into a list
    results <- list(Y1_ASM = Y1_ASM_new,
                    K1 = K1,
                    eff_len_g1 = eff_len_g1,
                    thetaNonzero1 = thetaNonzero1,
                    rUnique1 = rUnique1,
                    r1 = r1,
                    nIsoforms = nIsoforms_new,
                    redundantTag = redundantTag,
                    merge_info = merge_info)

  }

  results

}

