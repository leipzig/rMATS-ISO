#' prepare_data
#'
#' This function converts the raw data from files into a format usable
#' by the rMATS_Iso function in R
#'
#' @param IsoExon: Name of file containing isoform coordinates and isoform structure.
#' @param IsoMatrix1: Vector of file names for count data from group 1. Each file corresponds to a different replicate.
#' @param IsoMatrix2: Vector of file names for count data from group 2. Each file corresponds to a different replicate. If NULL, will only process sample group 1.
#' If there is only data available for 1 group, set IsoMatrix2 = NULL.
#' @return The function prepare_data returns a list containing the following elements:
#' \item{n_ASM}{Positive integer > 0. The number of alternative splicing modules (ASMs).}
#' \item{nExons}{Numeric vector. The number of exons in each ASM.}
#' \item{nIsoforms}{Numeric vector. The number of valid isoforms in each ASM.}
#' \item{n1}{Positive integer > 0. Number of replicates in group 1.}
#' \item{n2}{Positive integer > 0. Number of replicates in group 2 (only returned if there are data for 2 groups).}
#' \item{nReads1}{List of length n_ASM. Each element of nReads1 is a vector containing the total number of reads for each replicate in group 1.}
#' \item{nReads2}{List of length n_ASM. Each element of nReads2 is a vector containing the total number of reads for each replicate in group 2 (only returned if there are data for 2 groups).}
#' \item{ASM_names}{Vector containing the names of the ASMs.}
#' \item{readLengths1}{List of length n_ASM. Each element of readLengths1 is a vector containing the unique read lengths for that ASM in group 1.}
#' \item{readLengths2}{List of length n_ASM. Each element of readLengths2 is a vector containing the unique read lengths for that ASM in group 2 (only returned if there are data for 2 groups).}
#' \item{isoStruct}{Exon and isoform structure. Part of the output of prepare_data.R.}
#' \item{Y1}{List of length n_ASM. Each element of Y1 is a list containing the numReplicates1 x numValidPatterns isoform compatibility count matrices for each unique read length in group 1.}
#' \item{Y2}{List of length n_ASM. Each element of Y2 is a list containing the numReplicates2 x numValidPatterns isoform compatibility count matrices for each unique read length in group 2 (only returned if there are data for 2 groups).}
#' @export

prepare_data <- function(IsoExon, IsoMatrix1, IsoMatrix2 = NULL){

  ## Error messages and modifications
  if((class(IsoExon) != "character") | length(IsoExon) > 1){
    stop("IsoExon muts be a character string of length 1.")
  }

  if(class(IsoMatrix1) != "character" ){
    stop("IsoMatrix1 should be a character vector.")
  }

  if(class(IsoMatrix2) != "character" && !is.null(IsoMatrix2)){
    stop("IsoMatrix2 should either be NULL or a character vector.")
  }

  ########################################################
  ## Step 1: Create alternative splice module structure ##
  ########################################################

  ## Import ASM structure information
  cols_Exon  <- max(count.fields(IsoExon, sep = '', comment.char = ''))
  my.data    <- as.matrix(read.table(IsoExon, fill = TRUE, comment.char = "", row.names = NULL, header = FALSE, col.names = paste("V", 1:cols_Exon)))
  ASM_names  <- grep("ASM", my.data[,1], value = TRUE)
  n_ASM      <- length(ASM_names)
  start_rows <- which(grepl("ASM#", my.data[,1]))

  if(n_ASM == 1){
    end_rows <- nrow(my.data)
  }else{
    end_rows <- sapply(1:(n_ASM-1), function(i) start_rows[i+1]-1)
    end_rows <- c(end_rows, nrow(my.data))
  }

  ## Separate alternative splicing modules
  exonStructure <- lapply(1:n_ASM, function(i) my.data[start_rows[i]:end_rows[i], ])

  ##########################
  ## Compute exon lengths ##
  ##########################

  start_end   <- lapply(1:n_ASM, function(i) strsplit(exonStructure[[i]][2,], split = ","))
  start_end   <- lapply(1:n_ASM, function(i) lapply(start_end[[i]], function(x) x[!is.na(x)]))
  start_end   <- lapply(1:n_ASM, function(i) start_end[[i]][lapply(start_end[[i]], length) > 0])

  exon_start  <- lapply(1:n_ASM, function(i) as.numeric(sapply(1:length(start_end[[i]]), function(x) start_end[[i]][[x]][1])))
  exon_end    <- lapply(1:n_ASM, function(i) as.numeric(sapply(1:length(start_end[[i]]), function(x) start_end[[i]][[x]][2])))
  exonLengths <- lapply(1:n_ASM, function(i) exon_end[[i]] - exon_start[[i]] + 1)

  ## Save number of exons and number of isoforms
  nExons    <- sapply(1:n_ASM, function(i) length(exonLengths[[i]]))
  nIsoforms <- sapply(1:n_ASM, function(i) nrow(exonStructure[[i]]) - 2)

  ## Convert isoform structure into format suitable with rMATS-Iso
  Fmatrix  <- lapply(1:n_ASM, function(i) matrix(0, nrow = nIsoforms[i], ncol = nExons[i]))
  for(i in 1:n_ASM){
    l1           <- as.numeric(exonStructure[[i]][3:(nIsoforms[i]+2),1]) + 1
    incl_exons   <- lapply(1:nIsoforms[i], function(j) as.numeric(exonStructure[[i]][j+2,2:l1[j]]) + 1)
    for(j in 1:nIsoforms[i]){
      Fmatrix[[i]][j, incl_exons[[j]]] <- 1
    }
  }

  ## Save results into appropriate format for rMATS-Iso function
  isoStruct        <- lapply(1:n_ASM, function(i) list(Fmatrix = Fmatrix[[i]], exonLengths = exonLengths[[i]]))
  names(isoStruct) <- ASM_names

  ########################################
  ## Step 2: Convert isoform count data ##
  ########################################

  ##############
  ## Group 1: ##
  ##############

  ## List files for each group separately
  n1 <- length(IsoMatrix1)

  ## Load count data into 2 lists
  cols_g1   <- sapply(1:n1, function(i) max(count.fields(IsoMatrix1[i], sep = '', comment.char = '')))
  counts_g1 <- lapply(1:n1, function(i) as.matrix(read.table(IsoMatrix1[i], fill = TRUE, comment.char = "", row.names = NULL, header = FALSE, col.names = paste("V", 1:cols_g1[i]))))

  ## Find starting rows for ASMs; rows are replicates
  start_rows_g1 <- matrix(NA, nrow = n1, ncol = length(ASM_names))

  colnames(start_rows_g1) <- ASM_names

  for(i in 1:n1)
    start_rows_g1[i, ASM_names %in% counts_g1[[i]][,1]] <- which(grepl("ASM#", counts_g1[[i]][,1])) + 1

  ## Find ending rows for ASMs; rows are replicates
  end_rows_g1 <- matrix(NA, nrow = n1, ncol = length(ASM_names))

  colnames(end_rows_g1) <- ASM_names

  for(i in 1:n1)
    end_rows_g1[i, ASM_names %in% counts_g1[[i]][,1]] <- c((start_rows_g1[i,ASM_names %in% counts_g1[[i]][,1]])[-1] - 2, nrow(counts_g1[[i]]))

  ## Check for replicates with empty ASM read counts
  if(n_ASM == 1){
    g1_lengths <- end_rows_g1 - 1
  }else{
    g1_lengths <- t(sapply(1:n1, function(y) sapply(1:(n_ASM - 1), function(x) start_rows_g1[y,x+1] - start_rows_g1[y,x])))
  }

  diff1 <- (end_rows_g1 - start_rows_g1)
  start_rows_g1[which(diff1 < 0, arr.ind = TRUE)] <- NA
  end_rows_g1[which(diff1 < 0, arr.ind = TRUE)]   <- NA


  ##############
  ## Group 2: ##
  ##############

  if(!is.null(IsoMatrix2)){

    ## List files for each group separately
    n2 <- length(IsoMatrix2)

    ## Load count data into 2 lists
    cols_g2   <- sapply(1:n2, function(i) max(count.fields(IsoMatrix2[i], sep = '', comment.char = '')))
    counts_g2 <- lapply(1:n2, function(i) as.matrix(read.table(IsoMatrix2[i], fill = TRUE, comment.char = "", row.names = NULL, header = FALSE, col.names = paste("V", 1:cols_g2[i]))))

    ## Find starting rows for ASMs; rows are replicates
    start_rows_g2 <- matrix(NA, nrow = n2, ncol = length(ASM_names))

    colnames(start_rows_g2) <- ASM_names

    for(i in 1:n2)
      start_rows_g2[i, ASM_names %in% counts_g2[[i]][,1]] <- which(grepl("ASM#", counts_g2[[i]][,1])) + 1

    ## Find ending rows for ASMs; rows are replicates
    end_rows_g2 <- matrix(NA, nrow = n2, ncol = length(ASM_names))

    colnames(end_rows_g2) <- ASM_names

    for(i in 1:n2)
      end_rows_g2[i, ASM_names %in% counts_g2[[i]][,1]] <- c((start_rows_g2[i,ASM_names %in% counts_g2[[i]][,1]])[-1] - 2, nrow(counts_g2[[i]]))

    ## Check for replicates with empty ASM read counts
    if(n_ASM == 1){
      g2_lengths <- end_rows_g2 - 1
    }else{
      g2_lengths <- t(sapply(1:n2, function(y) sapply(1:(n_ASM - 1), function(x) start_rows_g2[y,x+1] - start_rows_g2[y,x])))
    }

    diff2 <- (end_rows_g2 - start_rows_g2)
    start_rows_g2[which(diff2 < 0, arr.ind = TRUE)] <- NA
    end_rows_g2[which(diff2 < 0, arr.ind = TRUE)]   <- NA

  }

  ###########################################
  ## Separate alternative splicing modules ##
  ###########################################

  ## Group 1
  ASM_g1       <- list()
  nReads1      <- list()
  for(i in 1:n_ASM){
    valid_reps     <- which(!is.na(start_rows_g1[,i]))
    nReads1[[i]]   <- rep(0, n1)
    if(length(valid_reps) == 0){
      ASM_g1[[i]]  <- list()
      #nReads1[[i]] <- c()
      nReads1[[i]] <- 0
      next
    }
    ASM_g1[[i]]  <- lapply(1:length(valid_reps), function(x) c())
    names(ASM_g1[[i]]) <- paste("Replicate#", valid_reps, sep = '')
    for(j in 1:length(valid_reps)){
      ASM_g1[[i]][[j]] <- counts_g1[[valid_reps[j]]][start_rows_g1[valid_reps[j],i]:end_rows_g1[valid_reps[j],i], 1:(nIsoforms[i] + 2)]
      if(class(ASM_g1[[i]][[j]]) == "character"){
        ASM_g1[[i]][[j]] <- t(as.matrix(ASM_g1[[i]][[j]]))
      }
    }
    nReads1[[i]][valid_reps] <- sapply(ASM_g1[[i]], function(x) sum(as.numeric(x[,2])))
  }

  ## Create names for list elements
  names(ASM_g1) <- ASM_names

  ## Group 2
  if(!is.null(IsoMatrix2)){
    ASM_g2  <- list()
    nReads2 <- list()
    for(i in 1:n_ASM){
      valid_reps   <- which(!is.na(start_rows_g2[,i]))
      nReads2[[i]] <- rep(0, n2)
      if(length(valid_reps) == 0){
        ASM_g2[[i]]  <- list()
        nReads2[[i]] <- 0
        next
      }
      ASM_g2[[i]] <- lapply(1:length(valid_reps), function(x) c())
      names(ASM_g2[[i]]) <- paste("Replicate#", valid_reps, sep = '')
      for(j in 1:length(valid_reps)){
        ASM_g2[[i]][[j]] <- counts_g2[[valid_reps[j]]][start_rows_g2[valid_reps[j],i]:end_rows_g2[valid_reps[j],i], 1:(nIsoforms[i] + 2)]
        if(class(ASM_g2[[i]][[j]]) == "character"){
          ASM_g2[[i]][[j]] <- t(as.matrix(ASM_g2[[i]][[j]]))
        }
      }
      nReads2[[i]][valid_reps] <- sapply(ASM_g2[[i]], function(x) sum(as.numeric(x[,2])))
    }

    ## Create names for list elements
    names(ASM_g2) <- ASM_names

  }

  ################################
  ## Save number of pseudoexons ##
  ################################

  if(n_ASM == 1){
    pseudo_left  <- as.numeric(counts_g1[[1]][start_rows_g1[1,] - 1, 4:5][1])
    pseudo_right <- as.numeric(counts_g1[[1]][start_rows_g1[1,] - 1, 4:5][2])
  }else{
    pseudo_left  <- as.numeric(counts_g1[[1]][start_rows_g1[1,] - 1, 4:5][,1])
    pseudo_right <- as.numeric(counts_g1[[1]][start_rows_g1[1,] - 1, 4:5][,2])
  }

  pseudo_left[is.na(pseudo_left)]   <- 0
  pseudo_right[is.na(pseudo_right)] <- 0

  ## Create pattern matrix and count pattern matches
  my.grid <- function(x){
    as.matrix(expand.grid(rep(list(c(0,1)), x)))[-1,]
  }

  ## Save pattern compatibility read counts
  Y1 <- list()
  for(i in 1:n_ASM){

    ## Create pattern dictionary matrix
    P <- my.grid(nIsoforms[i])

    ## If there are no reads in any replicate, skip
    if(sum(is.na(start_rows_g1[,i])) == n1){
      Y1[[i]] <- list()
    }else{

      ## Keep track of replicates
      Rep_g1 <- rep(1:length(ASM_g1[[i]]), times = as.numeric(sapply(ASM_g1[[i]], nrow)))
      cur_lengths1 <- sort(unique(as.numeric(Reduce("rbind", ASM_g1[[i]])[,1])))

      if(length(ASM_g1[[i]]) != 0){
        Y1[[i]] <- lapply(1:length(cur_lengths1), function(x) matrix(0, nrow = n1, ncol = nrow(P)))
        names(Y1[[i]]) <- cur_lengths1

        # Match reads to patterns
        all_reads1 <- Reduce("rbind", ASM_g1[[i]])
        tot_rows1  <- nrow(all_reads1)
        tP <- t(P)
        for(j in 1:tot_rows1){
           x       <- as.numeric(all_reads1[j,])
           v_row   <- which(colSums(abs(tP - x[-c(1,2)])) == 0)
           l_index <- which(cur_lengths1 == x[1])
           Y1[[i]][[l_index]][Rep_g1[j], v_row] <- Y1[[i]][[l_index]][Rep_g1[j], v_row] + x[2]
        }

        ## Remove any empty rows
        for(j in 1:length(cur_lengths1)){
          if(class(Y1[[i]][[j]]) == "numeric")
            Y1[[i]][[j]] <- t(as.matrix(Y1[[i]][[j]]))
          Y1[[i]][[j]] <- Y1[[i]][[j]][rowSums(Y1[[i]][[j]]) != 0, ]
          if(class(Y1[[i]][[j]]) == "numeric")
            Y1[[i]][[j]] <- t(as.matrix(Y1[[i]][[j]]))
        }

      }else{
        Y1[[i]] <- list()
      }
    }
  }

  # Name Y lists
  names(Y1) <- ASM_names

  if(!is.null(IsoMatrix2)){
    ## Save pattern compatibility read counts
    Y2 <- list()
    for(i in 1:n_ASM){

      ## Create pattern dictionary matrix
      P <- my.grid(nIsoforms[i])

      ## If there are no reads in any replicate, skip
      if(sum(is.na(start_rows_g2[,i])) == n2){
        Y2[[i]] <- list()
      }else{

        ## Keep track of replicates
        Rep_g2 <- rep(1:length(ASM_g2[[i]]), times = as.numeric(sapply(ASM_g2[[i]], nrow)))
        cur_lengths2 <- sort(unique(as.numeric(Reduce("rbind", ASM_g2[[i]])[,1])))

        if(length(ASM_g2[[i]]) != 0){
          Y2[[i]] <- lapply(1:length(cur_lengths2), function(x) matrix(0, nrow = n2, ncol = nrow(P)))
          names(Y2[[i]]) <- cur_lengths2

          # Match reads to patterns
          all_reads2 <- Reduce("rbind", ASM_g2[[i]])
          tot_rows2  <- nrow(all_reads2)
          tP <- t(P)
          for(j in 1:tot_rows2){
            x       <- as.numeric(all_reads2[j,])
            v_row   <- which(colSums(abs(tP - x[-c(1,2)])) == 0)
            l_index <- which(cur_lengths2 == x[1])
            Y2[[i]][[l_index]][Rep_g2[j], v_row] <- Y2[[i]][[l_index]][Rep_g2[j], v_row] + x[2]
          }

          ## Remove any empty rows
          for(j in 1:length(cur_lengths2)){
            if(class(Y2[[i]][[j]]) == "numeric")
              Y2[[i]][[j]] <- t(as.matrix(Y2[[i]][[j]]))
            Y2[[i]][[j]] <- Y2[[i]][[j]][rowSums(Y2[[i]][[j]]) != 0, ]
            if(class(Y2[[i]][[j]]) == "numeric")
              Y2[[i]][[j]] <- t(as.matrix(Y2[[i]][[j]]))
          }

        }else{
          Y2[[i]] <- list()
        }
      }
    }

    ## Name Y lists
    names(Y2) <- ASM_names

  }

  ## Read lengths
  readLengths1 <- lapply(1:n_ASM, function(i) as.numeric(names(Y1[[i]])))

  if(!is.null(IsoMatrix2)){
    readLengths2 <- lapply(1:n_ASM, function(i) as.numeric(names(Y2[[i]])))
  }

  ## Output results
  if(!is.null(IsoMatrix2)){
    results <- list(n_ASM = n_ASM, nExons = nExons, nIsoforms = nIsoforms,
                    n1 = n1, n2 = n2, nReads1 = nReads1, nReads2 = nReads2,
                    ASM_names = ASM_names,
                    readLengths1 = readLengths1,
                    readLengths2 = readLengths2,
                    isoStruct = isoStruct,
                    pseudo_left = pseudo_left,
                    pseudo_right = pseudo_right,
                    Y1 = Y1, Y2 = Y2)
  }else{
    results <- list(n_ASM = n_ASM, nExons = nExons, nIsoforms = nIsoforms,
                    n1 = n1, nReads1 = nReads1,
                    ASM_names = ASM_names,
                    readLengths1 = readLengths1,
                    isoStruct = isoStruct,
                    pseudo_left = pseudo_left,
                    pseudo_right = pseudo_right,
                    Y1 = Y1)
  }

  results

}
