#' Unconstrained optimization of the statistical model
#'
#' This function is used internally by rMATSISO to optimize the rMATS-Iso
#' statistical model with no constraints, and one sample group
#'
#' @param Y1_ASM_raw: List of read counts for group 1.
#' @param eff_len_g1: Matrix containing the effective lengths of each isoform for the reads in sample group 1.
#' @param nIsoforms_ind: Number of isoforms in this ASM.
#' @param n1: Number of replicates in group 1.
#' @param thetaNonzero1: List of pattern consistency matrices for each read length in group 1.
#' @param rUnique1: A vector containing the unique read lengths for this ASM in group 1.
#' @param r1: Number of unique read lengths in group 1.
#' @param S: Number of simulated samples to draw.
#' @param nIter: Max number of iterations of EM to perform. Default value is 100.
#' @param epsilon: Convergence criterion of EM algorith. Default value is 10^-2.
#' @return The function optim_u_one returns a list containing the following elements:
#' \item{alpha.u}{MLE of dirichlet paramater for unconstrained model.}
#' \item{u.iters}{Number of iterations for EM-algorithm to converge.}
#' \item{g1_param_u}{MLE of dirichlet paramater for unconstrained model (same as alpha.u).}
#' @export
#'
optim_u_one <- function(Y1_ASM, eff_len_g1, nIsoforms_ind, n1, thetaNonzero1, rUnique1, r1, S = 500, nIter = 100, epsilon = 10^-2){

  ## Initialize alpha.t
  alpha.t <- rbinom(nIsoforms_ind, 10, 0.5) + 1

  ## Implement importance sampling
  for(iter in 1:nIter){

    alpha.old <- alpha.t

    ## Generate sample for importance sampling
    psi.s1 <- rdirichlet(S, alpha = alpha.t[1:nIsoforms_ind])

    ## So we don't get -Inf when we take log
    psi.s1[psi.s1 <= 10^(-30)] <- 10^-30

    ## Remove any rows with NAs in it
    if(nrow(which(is.na(psi.s1), arr.ind = TRUE)) > 0)
      psi.s1 <- psi.s1[-which(is.na(psi.s1), arr.ind = TRUE)[,1],]

    S1      <- nrow(psi.s1)
    psi.s1  <- psi.s1[1:S1, ]

    log_omega_s1  <- list()
    psi.tilde1    <- list()

    for(rIndex in 1:r1){

      ## Adjust psi's with the effective lengths of each isoform
      psi.s1.adj <- sapply(1:nIsoforms_ind, function(f) eff_len_g1[rIndex,f] * psi.s1[,f])
      psi.s1.adj <- sapply(1:nIsoforms_ind, function(f) psi.s1.adj[,f] / rowSums(psi.s1.adj))

      ## Approximate expectation in EM step
      y1.ind <- which(names(thetaNonzero1) == rUnique1[rIndex])
      nRowY1 <- nrow(Y1_ASM[[y1.ind]])
      log_omega_s1[[rIndex]] <- matrix(0, nrow = nRowY1, ncol = S1)
      theta_psi1 <- log(thetaNonzero1[[y1.ind]] %*% t(psi.s1.adj))
      for(k in 1:nRowY1){
        log_inner_term1 <- theta_psi1 * Y1_ASM[[y1.ind]][k,]
        log_inner_term1[is.nan(log_inner_term1)] <- 0
        log_omega_s1[[rIndex]][k,] <- colSums(log_inner_term1)
      }
    }

    sum_log_omega_s1 <- Reduce('+', log_omega_s1)
    a1 <- log(rowSums(exp(t(apply(sum_log_omega_s1, 1, function(x) x - max(x))))))
    b1 <- apply(sum_log_omega_s1, 1, max)

    omega_s1_dividedrow <- exp(sum_log_omega_s1 - (a1 + b1))
    omega_s1_dividedrow[omega_s1_dividedrow <= 10^(-250)] <- 10^(-250)

    ## Importance approximation to E[log(psi)|Y,alpha]
    psi.tilde1 <- omega_s1_dividedrow %*% log(psi.s1)

    ## Maximize ll_EM with current parameter
    res.u <- lbfgs(alpha.t, fn = ll_EM, gr = ll_EM_gr,
                   lower = rep(10^(-10), nIsoforms_ind),
                   upper = rep(100, nIsoforms_ind),
                   psi.tilde1 = psi.tilde1,
                   n1 = n1,
                   nIsoforms = nIsoforms_ind,
                   num_groups = 1)

    alpha.t <- res.u$par

    if(sum((alpha.t - alpha.old)^2) < epsilon){
      break
    }

  }
  alpha.u <- alpha.t
  u.iters <- iter

  ## Save expected isoform inclusion probabilities
  g1_param_u   <- alpha.u

  ## Save results
  results <- list(alpha.u = alpha.u, u.iters = u.iters,
                  g1_param_u = g1_param_u)

  results

}
