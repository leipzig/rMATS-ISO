#' Create a pattern grid
#'
#' Used internally by rMATSISO. This function creates a matrix of all
#' possible isoform consistency patterns.
#'
#' @param x Positive integer > 0. Number of valid isoforms.
#' @return The function pattern_grid returns the following:
#' \item{P}{Matrix with 2^nExons - 1 rows and x columns. Each row is a possible pattern of isoform compatibility.}
#' @export

## The pattern of all zeros is not valid, hence the '-1'.
pattern_grid <- function(x){
  as.matrix(expand.grid(rep(list(c(0,1)), x)))[-1,]
}
