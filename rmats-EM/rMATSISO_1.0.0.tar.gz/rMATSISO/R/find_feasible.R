#' Find feasible exon body reads and junction reads
#'
#' Used internally by rMATSISO. This function finds the total number of unique read
#' positions corresponding to each pattern and isoform.
#'
#' @param nIsoforms Positive integer > 0. The number of valid isoforms in this ASM.
#' @param nExons Positive integer > 0. The number of exons in this ASM.
#' @param r Positive integer > 0. RNA-Seq read length.
#' @param isoStruct Exon and isoform structure. Part of the output of prepare_data.R.
#' @return The function find_feasible returns a list containing the following elements:
#' \item{feasibleBodies}{List with nIsoforms elements. Each element contains the exon bodys which can feasibly be read (as determined by the read length r and exon lengths).}
#' \item{feasibleJunctions}{List with nIsoforms elements. Each element contains the exon junctions which can feasibly be read (as determined by the read length r and exon lengths).}
#' \item{isoStruct}{Exon and isoform structure. Part of the output of prepare_data.R.}
#' @export

find_feasible <- function(nIsoforms, nExons, r, isoStruct){

  Fmatrix     <- isoStruct$Fmatrix
  exonLengths <- isoStruct$exonLengths

  allJunctions <- list()
  allBodies    <- list()

  feasibleJunctions <- list()
  feasibleBodies    <- list()

  for(isof in 1:nIsoforms){

    ## Enumerate all possible bodies
    validExons        <- which(Fmatrix[isof, ] == 1)
    allBodies[[isof]] <- validExons

    ## Enumerate all possible junctions
    loopRange  <- length(validExons) - 1
    allJunctions[[isof]] <- NA

    if(loopRange == 0){
      feasibleBodies[[isof]] <- validExons[exonLengths[validExons] >= r]
      feasibleJunctions[[isof]] <- NA
      next
    }

    k <- 1
    for(j in 1:loopRange){
      for(i in j:loopRange){
        junction <- c(validExons[j], validExons[(j + 1):(i + 1)])
        allJunctions[[isof]][k] <- paste(as.character(junction), collapse = " ")
        k <- k + 1
      }
    }

    ## Rule out the impossible (based on exon length and read length)
    ## patterns from the junction and body reads

    ## Exon body reads
    feasibleBodies[[isof]] <- validExons[exonLengths[validExons] >= r]

    ## Junction reads
    feasibleJunctions[[isof]] <- NA

    k <- 1
    for(i in 1:length(allJunctions[[isof]])){
      currentJunc <- strtoi(unlist(strsplit(allJunctions[[isof]][[i]], " ")))
      juncLength  <- exonLengths[currentJunc]

      ## For the current junction to be feasible, we need :
      ## 1) the total junction length is at least as large
      ## as the read length
      ## 2) at least one read position should start from the
      ## first exon in the junction, and end in the last exon
      ## of the junction

      is_long <- sum(juncLength) >= r
      is_span <- juncLength[1] + r - 1 > tail(cumsum(juncLength), 2)[1]

      if(is_long & is_span){
        feasibleJunctions[[isof]][k] <- allJunctions[[isof]][[i]]
        k <- k + 1
      }
    }
  }

  list(feasibleBodies = feasibleBodies,
       feasibleJunctions = feasibleJunctions,
       isoStruct = isoStruct)

}
