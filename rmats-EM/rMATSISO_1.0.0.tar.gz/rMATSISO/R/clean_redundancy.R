#' Clean the given alternative splicing module and tag invalid cases
#'
#' This function is used internally by rMATSISO to filter away invalid
#' isoforms within an ASM. The default version returns "NA" if at least
#' one isoform is completely embedded in another.
#'
#' @param isoStruct_ind: Exon and isoform structure. Part of the output of prepare_data.R.
#' @param nIsoforms_ind: Vector of file names for count data from group 1. Each file corresponds to a different replicate.
#' @return The function clean_redundancy returns a list containing the elements listed below:
#' \item{isoStruct}{Updated exon and isoform structure.}
#' \item{nIsoforms}{Updated number of isoforms in this ASM.}
#' \item{redundantTag}{Binary vector indicating which isoforms were tagged as being redundant.}
#' \item{merge_info}{Either "NA", or vector of strings indicating which isoforms have been merged into other isoforms.}
#' @export
#'

clean_redundancy <- function(isoStruct_ind, nIsoforms_ind){

  ## Find isoforms which are 'gapless embedded isoforms'
  Fmatrix       <- isoStruct_ind$Fmatrix
  n             <- nrow(Fmatrix)
  redundant     <- rep(0, n)
  merge_info    <- c()
  merge_info[1] <- NA
  k             <- 1
  for(i in 1:n){

    ei <- Fmatrix[i,]
    for(j in 1:n){
      if(i == j)
        next

      ej <- Fmatrix[j,]
      if(sum(ei) >= sum(ej))
        next

      ## Is ei in ej?
      ei_firstone <- min(which(ei == 1))
      ej_firstone <- min(which(ej == 1))

      if(ei_firstone < ej_firstone)
        next

      first_one    <- min(which(ei == 1))
      last_one     <- max(which(ei == 1))
      is.redundant <- all(ei[first_one:last_one] == ej[first_one:last_one])

      if(is.redundant){
        redundant[i]  <- 1
        merge_info[k] <- paste(i, "_into_", j, sep = '')
        k <- k + 1
        next
      }

    }
  }

  ## Remove these isoforms; if only 1 isoform remains, skip this ASM
  if(sum(redundant == 0) == 1)
    return(NA)

  ## Ignore ASMs with at least 1 "redundant" isoform
  if(sum(redundant) > 0)
    return(NA)

  Fmatrix_new   <- Fmatrix[which(redundant == 0), ]
  nIsoforms_new <- nIsoforms_ind - sum(redundant)
  isoStruct_new <- list(Fmatrix = Fmatrix_new, exonLengths = isoStruct_ind$exonLengths)

  ## Remove all patterns and reads corresponding to redundant isoforms
  output <- list(isoStruct = isoStruct_new,
                 nIsoforms = nIsoforms_new,
                 redundantTag = redundant,
                 merge_info = merge_info)
  return(output)


}
