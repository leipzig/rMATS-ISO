#' Find the total number of read locations compatible
#' with each feasible body and junction read
#'
#' Used internally by rMATSISO. This function finds the read locations that are compatible
#' with each isoform/pattern combination.
#'
#' @param nIsoforms Positive integer > 0. The number of valid isoforms in this ASM.
#' @param nExons Positive integer > 0. The number of exons in this ASM.
#' @param r Positive integer > 0. RNA-Seq read length.
#' @param isoStruct Exon and isoform structure. Part of the output of prepare_data.R.
#' @return The function find_readlocs returns a list containing the following elements:
#' \item{patternBody}{List with 2^nExons - 1 elements. Each element contains the exon body read locations compatible with a compatibility pattern.}
#' \item{patternJunc}{List with 2^nExons - 1 elements. Each element contains the junction read locations compatible with a compatibility pattern.}
#' \item{isoStruct}{Exon and isoform structure. Part of the output of prepare_data.R.}
#' @export


find_readlocs <- function(nIsoforms, nExons, r, isoStruct){

  feasible          <- find_feasible(nIsoforms, nExons, r, isoStruct)
  feasibleBodies    <- feasible$feasibleBodies
  feasibleJunctions <- feasible$feasibleJunctions

  patternJunc <- list()
  patternBody <- list()

  ## Create the pattern matrix
  P <- pattern_grid(nIsoforms)

  for(p in 1:nrow(P)){

    ## First, obtain all of the feasible junction and body reads
    ## corresponding to the current pattern.

    ## STEP 1: JUNCTIONS

    ## Intersect everything for which pattern is 1, then from this
    ## take out everything for which pattern is 0
    pattern <- as.numeric(P[p, ])
    possibleJuncs   <- unlist(feasibleJunctions[which(pattern == 1)])
    impossibleJuncs <- unlist(feasibleJunctions[which(pattern == 0)])
    impossibleJuncs <- unique(impossibleJuncs)

    ## Intersect all sets which have pattern = 1
    valid <- feasibleJunctions[which(pattern == 1)]
    if(sum(pattern) > 1){
      candidateJuncs <- possibleJuncs
      for(t in 1:(sum(pattern) - 1)){
        candidateJuncs <- intersect(candidateJuncs, intersect(valid[[t]], valid[[t+1]]))
      }
    }else{
      candidateJuncs <- valid[[1]]
    }

    ## From the intersection computed above, remove the elements
    ## in impossibleJuncs
    patternJunc[[p]] <- setdiff(candidateJuncs, impossibleJuncs)
    if(length(patternJunc[[p]]) == 0){
      patternJunc[[p]] <- NA
    }

    ## STEP 2: BODIES
    possibleBodies   <- unlist(feasibleBodies[which(pattern == 1)])
    impossibleBodies <- unlist(feasibleBodies[which(pattern == 0)])
    impossibleBodies <- unique(impossibleBodies)

    ## Intersect all sets which have pattern = 1
    valid <- feasibleBodies[which(pattern == 1)]
    if(sum(pattern) > 1){
      candidateBodies <- possibleBodies
      for(t in 1:(sum(pattern) - 1)){
        candidateBodies <- intersect(candidateBodies, intersect(valid[[t]], valid[[t+1]]))
      }
    }else{
      candidateBodies <- valid[[1]]
    }

    ## From the intersection computed above, remove the elements
    ## in impossibleBodies
    patternBody[[p]] <- setdiff(candidateBodies, impossibleBodies)
    if(length(patternBody[[p]]) == 0){
      patternBody[[p]] <- NA
    }

  }

  list(patternBody = patternBody,
       patternJunc = patternJunc,
       isoStruct = isoStruct)

}
