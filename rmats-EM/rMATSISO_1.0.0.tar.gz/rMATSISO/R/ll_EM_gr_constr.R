#' Gradient of negative E-step of EM algorithm
#'
#' Used internally by rMATSISO. Function for computing the gradient of the negative E step of
#' the EM algorithm for the constrained model
#'
#' @param x Parameter vector for Dirichlet distribution.
#' @param psi.tilde1 Expected psi matrix for group 1.
#' @param psi.tilde2 Expected psi matrix for group 2.
#' @param n1 Sample size for this ASM in group 1.
#' @param n2 Sample size for this ASM in group 2.
#' @return The function ll_EM_gr_constr returns the following:
#' \item{y}{Value of the gradient of the negative E step of the constrained model}
#' @export
#'

## Gradient of negative E step
ll_EM_gr_constr <- function(x, psi.tilde1, psi.tilde2, n1, n2){

  a1 <- -n1 * (digamma(x) - digamma(sum(x)))
  a2 <- -n2 * (digamma(x) - digamma(sum(x)))

  a3 <- colSums(psi.tilde1)
  a4 <- colSums(psi.tilde2)

  -(a1+a2+a3+a4)

}
