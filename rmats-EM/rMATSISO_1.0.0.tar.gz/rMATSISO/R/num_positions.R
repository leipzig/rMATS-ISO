#' Compute the total number of read positions that are
#' compatible with each junction or body element
#'
#' Used internally by rMATSISO. This function finds the number of read positions that are
#' compatible with each isoform/pattern combination.
#'
#' @param nIsoforms Positive integer > 0. The number of valid isoforms in this ASM.
#' @param nExons Positive integer > 0. The number of exons in this ASM.
#' @param r Positive integer > 0. RNA-Seq read length.
#' @param isoStruct Exon and isoform structure. Part of the output of PrepareData.R.
#' @return The function num_positions returns a list containing the following elements:
#' \item{positionCounts}{Matrix with 2^nExons - 1 rows and nIsoforms columns. positionCounts[i,j] is the total number of feasible read positions for pattern i assuming isoform j generated the read.}
#' \item{isoStruct}{Exon and isoform structure. Part of the output of prepare_data.R.}
#' @export

num_positions <- function(nIsoforms, nExons, r, isoStruct){

  findLocs    <- find_readlocs(nIsoforms, nExons, r, isoStruct)
  patternBody <- findLocs$patternBody
  patternJunc <- findLocs$patternJunc
  exonLengths <- isoStruct$exonLengths

  ## Create the pattern matrix
  P <- pattern_grid(nIsoforms)

  N <- matrix(0, nrow = nrow(P), ncol = ncol(P))
  for(p in 1:nrow(P)){

    pattern <- as.numeric(P[p, ])

    ## Count body positions
    curBody       <- patternBody[[p]]
    bodyPositions <- 0
    if(all(!is.na(curBody))){
      bodyPositions <- sum(exonLengths[curBody] - r + 1)
    }

    ## Count junction positions
    curJunction   <- patternJunc[[p]]
    juncPositions <- 0
    if(all(!is.na(curJunction))){
      numJunctions  <- length(curJunction)
      juncPositions <- rep(0, numJunctions)
      for(j in 1:numJunctions){
        indJunction <- strtoi(unlist(strsplit(curJunction[j], " ")))
        locs   <- (1:exonLengths[indJunction][1]) + r - 1
        finish <- tail(cumsum(exonLengths[indJunction]), 2)[1]

        is_long  <- (locs > finish)
        is_bound <- (locs <= sum(exonLengths[indJunction]))
        juncPositions[j] <- length(which(is_long & is_bound))
      }
    }

    n      <- bodyPositions + sum(juncPositions)
    N[p, ] <- pattern * n

  }

  list(positionCounts = N, isoStruct = isoStruct)

}

