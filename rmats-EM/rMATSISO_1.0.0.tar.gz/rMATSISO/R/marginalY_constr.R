#' Negative marginal likelihood of observed data
#'
#' Used internally by rMATSISO. Function for computing the marginal
#' log likelihood of observed data for the constrained model
#'
#' @param x Parameter vector for Dirichlet distribution under constrained model.
#' @param nIsoforms Positive integer > 0. The number of valid isoforms in this ASM.
#' @param rUnique1 Positive integer > 0. RNA-Seq read length for group 1.
#' @param rUnique2 Positive integer > 0. RNA-Seq read length for group 2.
#' @param thetaNonzero1 Reduced feasability probability matrix for group 1.
#' @param thetaNonzero2 Reduced feasability probability matrix for group 2.
#' @param Y1_ASM List of read counts corresponding to patterns in group 1 for this ASM.
#' @param Y2_ASM List of read counts corresponding to patterns in group 2 for this ASM.
#' @param n1 Sample size for this ASM in group 1.
#' @param n2 Sample size for this ASM in group 2.
#' @param S Number of simulated samples to draw.
#' @return The function marginalY_constr returns the following:
#' \item{y}{Value of the negative marginal likelihood of observed data for the constrained model.}
#' @export
#'

marginalY_constr <- function(x, nIsoforms, rUnique1, rUnique2,
                        thetaNonzero1, thetaNonzero2,
                        eff_len_g1, eff_len_g2,
                        Y1_ASM, Y2_ASM, n1, n2, S = 500){

  if(length(x) != nIsoforms){
    stop("Error: x must be of length nIsoforms in constrained model")
  }

  # Create simulated data to approximate marginal likelihood
  psi.s1 <- rdirichlet(S, alpha = x)
  psi.s2 <- rdirichlet(S, alpha = x)

  ## So we don't get -Inf when we take log
  psi.s1[log(psi.s1) == -Inf] <- 10^-300
  psi.s2[log(psi.s2) == -Inf] <- 10^-300

  r1 <- length(rUnique1)
  r2 <- length(rUnique2)

  log_omega_s1  <- list()
  log_omega_s2  <- list()

  for(rIndex in 1:r1){

    ## Adjust psi's with the effective lengths of each isoform
    psi.s1.adj <- sapply(1:nIsoforms, function(f) eff_len_g1[rIndex,f] * psi.s1[,f])
    psi.s1.adj <- sapply(1:nIsoforms, function(f) psi.s1.adj[,f] / rowSums(psi.s1.adj))

    ## Approximate expectation in EM step
    y1.ind <- which(names(thetaNonzero1) == rUnique1[rIndex])
    nRowY1 <- nrow(Y1_ASM[[y1.ind]])
    log_omega_s1[[rIndex]] <- matrix(0, nrow = nRowY1, ncol = S)
    theta_psi1 <- log(thetaNonzero1[[y1.ind]] %*% t(psi.s1.adj))
    for(k in 1:nRowY1){
      log_inner_term1 <- theta_psi1 * Y1_ASM[[y1.ind]][k,]
      log_inner_term1[is.nan(log_inner_term1)] <- 0
      log_omega_s1[[rIndex]][k,] <- colSums(log_inner_term1)
    }
  }

  sum_log_omega_s1 <- Reduce('+', log_omega_s1)
  max_k     <- sapply(1:nRowY1, function(i) max(sum_log_omega_s1[i,]))
  sum_exp_k <- rowSums(exp(t(sapply(1:nRowY1, function(i) sum_log_omega_s1[i,] - max_k[i]))))
  result1   <- sum(max_k) + sum(log(sum_exp_k))

  for(rIndex in 1:r2){

    ## Adjust psi's with the effective lengths of each isoform
    psi.s2.adj <- sapply(1:nIsoforms, function(f) eff_len_g2[rIndex,f] * psi.s2[,f])
    psi.s2.adj <- sapply(1:nIsoforms, function(f) psi.s2.adj[,f] / rowSums(psi.s2.adj))

    ## Approximate expectation in EM step
    y2.ind <- which(names(thetaNonzero2) == rUnique2[rIndex])
    nRowY2 <- nrow(Y2_ASM[[y2.ind]])
    log_omega_s2[[rIndex]] <- matrix(0, nrow = nRowY2, ncol = S)
    theta_psi2 <- log(thetaNonzero2[[y2.ind]] %*% t(psi.s2.adj))
    for(k in 1:nRowY2){
      log_inner_term2 <- theta_psi2 * Y2_ASM[[y2.ind]][k,]
      log_inner_term2[is.nan(log_inner_term2)] <- 0
      log_omega_s2[[rIndex]][k,] <- colSums(log_inner_term2)
    }
  }

  sum_log_omega_s2 <- Reduce('+', log_omega_s2)
  max_k     <- sapply(1:nRowY2, function(i) max(sum_log_omega_s2[i,]))
  sum_exp_k <- rowSums(exp(t(sapply(1:nRowY2, function(i) sum_log_omega_s2[i,] - max_k[i]))))
  result2   <- sum(max_k) + sum(log(sum_exp_k))

  result1 + result2

}
