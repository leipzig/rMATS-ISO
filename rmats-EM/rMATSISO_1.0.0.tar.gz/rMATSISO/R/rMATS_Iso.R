#' rMATS-Iso statistical model
#'
#' This is the primary function of the rMATSISO package
#' that implements the rMATS-Iso statistical algorithm. Provides estimates
#' of isoform inclusion levels; if two-samples are provided, will also perform
#' a test of differential alternative splicing
#'
#' @param IsoExon: Name of file containing isoform coordinates and isoform structure.
#' @param IsoMatrix1: Vector of file names for count data from group 1. Each file corresponds to a different replicate.
#' @param IsoMatrix2: Vector of file names for count data from group 2. Each file corresponds to a different replicate.
#' @param outfile: String containing the name of the output file which will be written.
#' @param numClusters: Integer specifying how many computing clusters will be used. Default value is 4.
#' @param detect_clusters: Logical. Should the number of cores be automatically determined? Default value is FALSE.
#' @param seed: Random seed.
#' @param S: Number of samples to draw for importance sampling. Default value is 500.
#' @param pval_thresh: Below which module-wise p-value shall individual isoform differences be tested? Default value is 1.
#' @param S_pairwise: Number of simulations to perform to compute pairwise isoform p-values. Default value is 1e+05.
#' @param nIter: Maximum number of EM iterations to perform. Default value is 100.
#' @param epsilon: Convergence criterion of EM algorithm. Default value is 10^-2.
#' @return The function rMATS_Iso creates a text file named outfile containing the elements listed below. In addition, rMATS_Iso returns a list containing the following elements:
#' \item{ASM_NAME}{Vector of names for the alternative splicing modules.}
#' \item{Iso_Num}{Vector of total number of isoforms for each ASM.}
#' \item{Exon_Num}{Vector of total number of exons for each ASM}
#' \item{total_read_count_g1}{Vector of total number of RNA-seq reads for each ASM in group 1.}
#' \item{total_read_count_g2}{Vector of total number of RNA-seq reads for each ASM in group 2.}
#' \item{Pvalue}{Vector of p-values for likelihood ratio test of equality of isoform inclusion levels between group 1 and group 2.}
#' \item{testStat}{Vector of test statistics for likelihood ratio test of equality of isoform inclusion levels between group 1 and group 2.}
#' \item{isof_incl_unconstrained_g1}{List of expected isoform inclusion levels for group 1 according to the unconstrained model.}
#' \item{isof_incl_unconstrained_g2}{List of expected isoform inclusion levels for group 2 according to the unconstrained model.}
#' \item{isof_incl_constrained}{List of expected isoform inclusion levels for both groups according to the constrained model.}
#' \item{variance_unconstrained_g1}{List of variances of isoform inclusion levels for group 1 according to the unconstrained model.}
#' \item{variance_unconstrained_g2}{List of variances of isoform inclusion levels for group 2 according to the unconstrained model.}
#' \item{variance_constrained}{List of variances of isoform inclusion levels for both groups according to the constrained model.}
#' \item{num_iters_unconstrained}{Vector of total number of EM iterations for each ASM under the unconstrained model.}
#' \item{num_iters_constrained}{Vector of total number of EM iterations for each ASM under the constrained model.}
#' \item{param_unconstrained_g1}{List of fitted Dirichlet parameters for group 1 under unconstrained model.}
#' \item{param_unconstrained_g2}{List of fitted Dirichlet parameters for group 2 under unconstrained model.}
#' \item{param_constrained}{List of fitted Dirichlet parameters for both groups under constrained model.}
#' @export
#'

rMATS_Iso <- function(IsoExon, IsoMatrix1, IsoMatrix2 = NULL,
                    outfile, detect_clusters = FALSE,
                    numClusters = 4, seed = 17495,
                    S = 500, pval_thresh = 1,
                    S_pairwise = 1e+05, nIter = 100,
                    epsilon = 10^-2){

  ##################
  ## Check inputs ##
  ##################

  numeric_classes <- c('numeric', 'integer')

  if(class(detect_clusters) != 'logical' | is.na(detect_clusters))
    stop('Error: detect_clusters must be either TRUE or FALSE')

  if(numClusters <= 0 | !(class(numClusters) %in% numeric_classes))
    stop('Error: numClusters must be a positive integer')

  if(!(class(seed) %in% numeric_classes))
    stop('Error: seed must be a number')

  if(!(class(S) %in% numeric_classes) | S <= 0)
    stop('Error: S must be a positive number')

  if(!(class(pval_thresh) %in% numeric_classes) |
     (pval_thresh <= 0 | pval_thresh > 1))
    stop('Error: pval_thresh must be a number between 0 and 1')

  if(S_pairwise <= 0 | !(class(S_pairwise) %in% numeric_classes))
    stop('Error: S_pairwise must be a non-negative number')

  if(S_pairwise > 1e+06)
    warning('Warning: S_pairwise is quite large (this may take a while)')

  if(nIter <= 0 | !(class(nIter) %in% numeric_classes))
    stop('Error: nIter must be a non-negative number')

  if(nIter >= 200)
    warning('Warning: nIter is quite large (this may take a while)')

  if(epsilon <= 0 | !(class(epsilon) %in% numeric_classes))
    stop('Error: epsilon must be a non-negative number')

  if(epsilon < 10^-4)
    warning('Warning: epsilon is quite small (this may take a while)')

  ## One or two groups?
  num_groups <- 2
  if(is.null(IsoMatrix2))
    num_groups <- 1

  ###############################################
  ## Step 1: Prepare the raw data for analysis ##
  ###############################################

  prep_data    <- prepare_data(IsoExon, IsoMatrix1, IsoMatrix2)
  n_ASM        <- prep_data$n_ASM
  ASM_names    <- prep_data$ASM_names
  nExons       <- prep_data$nExons
  nIsoforms    <- prep_data$nIsoforms
  isoStruct    <- prep_data$isoStruct
  pseudo_left  <- prep_data$pseudo_left
  pseudo_right <- prep_data$pseudo_right
  n1           <- prep_data$n1
  nReads1      <- prep_data$nReads1
  readLengths1 <- prep_data$readLengths1
  Y1           <- prep_data$Y1

  ## Save second group's data if available
  if(num_groups == 2){
    n2           <- prep_data$n2
    nReads2      <- prep_data$nReads2
    readLengths2 <- prep_data$readLengths2
    Y2           <- prep_data$Y2
  }

  ## Setup parallel backend to use multiple processors
  if(detect_clusters == TRUE)
    numClusters <- parallel::detectCores()

  cl <- makeCluster(numClusters)
  registerDoParallel(cl)

  writeLines(c(""), 'rMATS_Iso_status.txt')
  results <- foreach(ind_ASM = 1:n_ASM, .combine = cbind, .packages = c("nloptr")) %dopar% {

    sink('rMATS_Iso_status.txt', append = TRUE)
    cat(paste0(round(ind_ASM / n_ASM * 100), '% completed', '\n'), sep = "")
    sink()

    cat("\nCurrently on iteration", ind_ASM)

    ###########################################################################
    ## Step 2: Generate consistency probabilities; tag invalid ASMs with NAs ##
    ###########################################################################

    if(num_groups == 1){
      cleaned_module <- clean_module(num_groups, Y1[[ind_ASM]], NULL,
                                     pseudo_left[ind_ASM], pseudo_right[ind_ASM],
                                     isoStruct[[ind_ASM]],
                                     readLengths1[[ind_ASM]], NULL,
                                     nIsoforms[ind_ASM], nExons[ind_ASM], n1, NULL)

      if(is.na(cleaned_module))
        return(NA)

    }else{
      cleaned_module <- clean_module(num_groups, Y1[[ind_ASM]], Y2[[ind_ASM]],
                                     pseudo_left[ind_ASM], pseudo_right[ind_ASM],
                                     isoStruct[[ind_ASM]],
                                     readLengths1[[ind_ASM]], readLengths2[[ind_ASM]],
                                     nIsoforms[ind_ASM], nExons[ind_ASM], n1, n2)

      if(is.na(cleaned_module))
        return(NA)

      Y2_ASM        <- cleaned_module$Y2_ASM
      K2            <- cleaned_module$K2
      eff_len_g2    <- cleaned_module$eff_len_g2
      thetaNonzero2 <- cleaned_module$thetaNonzero2
      rUnique2      <- cleaned_module$rUnique2
      r2            <- cleaned_module$r2
    }

    Y1_ASM        <- cleaned_module$Y1_ASM
    K1            <- cleaned_module$K1
    eff_len_g1    <- cleaned_module$eff_len_g1
    thetaNonzero1 <- cleaned_module$thetaNonzero1
    rUnique1      <- cleaned_module$rUnique1
    r1            <- cleaned_module$r1
    nIsoforms_ind <- cleaned_module$nIsoforms
    redundantTag  <- which(cleaned_module$redundantTag == 0)
    merge_info    <- cleaned_module$merge_info
    #nIsoforms[ind_ASM] <- nIsoforms_ind

    ################################################
    ## Step 3: Begin EM algorithm; optimize model ##
    ################################################

    ## Set random seed
    set.seed(seed)

    ## ~~~~~~~~~~~~~~~~~~~~~~~~~~ ##
    ## Unconstrained optimization ##
    ## ~~~~~~~~~~~~~~~~~~~~~~~~~~ ##

    ## Save expected isoform inclusion probabilities and variances
    if(num_groups == 1){
      unconstr_results <- optim_u_one(Y1_ASM, eff_len_g1, nIsoforms_ind, K1,
                                      thetaNonzero1, rUnique1, r1, S, nIter, epsilon)
    }else{
      unconstr_results <- optim_u_two(Y1_ASM, Y2_ASM, eff_len_g1, eff_len_g2,
                                      nIsoforms_ind, K1, K2,
                                      thetaNonzero1, thetaNonzero2,
                                      rUnique1, rUnique2, r1, r2, S, nIter, epsilon)

      g2_param_u <- unconstr_results$g2_param_u
      a0_g2_u    <- sum(g2_param_u)

      ## Isoform probabilities and variances
      isof_incl_u2 <- g2_param_u / a0_g2_u
      var_g2_u     <- (g2_param_u * (a0_g2_u - g2_param_u)) / ((a0_g2_u^2) * (a0_g2_u + 1))
    }

    alpha.u    <- unconstr_results$alpha.u
    u.iters    <- unconstr_results$u.iters
    g1_param_u <- unconstr_results$g1_param_u
    a0_g1_u    <- sum(g1_param_u)

    ## Isoform probabilities and variances
    isof_incl_u1 <- g1_param_u / a0_g1_u
    var_g1_u     <- (g1_param_u * (a0_g1_u - g1_param_u)) / ((a0_g1_u^2) * (a0_g1_u + 1))

    ## ~~~~~~~~~~~~~~~~~~~~~~~~ ##
    ## Constrained optimization ##
    ## ~~~~~~~~~~~~~~~~~~~~~~~~ ##

    if(num_groups == 2){

      constr_results <- optim_c(Y1_ASM, Y2_ASM, eff_len_g1, eff_len_g2,
                                nIsoforms_ind, K1, K2,
                                thetaNonzero1, thetaNonzero2,
                                rUnique1, rUnique2, r1, r2, S, nIter, epsilon)

      alpha.c <- constr_results$alpha.c
      c.iters <- constr_results$c.iters
      a0_c    <- sum(alpha.c)

      ## Isoform probabilities and variances
      isof_incl_c <- alpha.c / a0_c
      var_c       <- (alpha.c * (a0_c - alpha.c)) / ((a0_c^2) * (a0_c + 1))

    }

    ## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ ##
    ## Likelihood ratio test and p-values ##
    ## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ ##

    if(num_groups == 2){

      ## Calculate likelihood ratio
      m.c <- marginalY_constr(alpha.c, nIsoforms_ind, rUnique1, rUnique2, thetaNonzero1,
                         thetaNonzero2, eff_len_g1, eff_len_g2,
                         Y1_ASM, Y2_ASM, K1, K2, S)

      m.u <- marginalY(alpha.u, nIsoforms_ind, rUnique1, rUnique2, thetaNonzero1,
                       thetaNonzero2, eff_len_g1, eff_len_g2,
                       Y1_ASM, Y2_ASM, K1, K2, S)


      test.stat <- max(0, -2 * (m.c - m.u))
      pval      <- 1 - pchisq(test.stat, nIsoforms_ind)

      ## If significant, find which pair contributes the difference
      isoform_pvals <- rep(NA, nIsoforms_ind)
      if((pval <= pval_thresh) & (nIsoforms_ind > 2))
        isoform_pvals <- pairwise_test(nIsoforms_ind, K1, K2, alpha.c, isof_incl_u1, isof_incl_u2, S_pairwise)

      result <- list(ASM_NAME = ASM_names[ind_ASM],
                     Iso_Num = nIsoforms_ind,
                     Exon_Num = nExons[ind_ASM],
                     Pvalue = pval,
                     testStat = test.stat,
                     isof_incl_unconstrained_g1 = isof_incl_u1,
                     isof_incl_unconstrained_g2 = isof_incl_u2,
                     isof_incl_constrained = isof_incl_c,
                     variance_unconstrained_g1 = var_g1_u,
                     variance_unconstrained_g2 = var_g2_u,
                     variance_constrained = var_c,
                     num_iters_unconstrained = u.iters,
                     num_iters_constrained = c.iters,
                     param_unconstrained_g1 = alpha.u[1:nIsoforms_ind],
                     param_unconstrained_g2 = alpha.u[(nIsoforms_ind+1):(2*nIsoforms_ind)],
                     param_constrained = alpha.c,
                     isoform_pvals = isoform_pvals,
                     isoform_index = redundantTag,
                     merge_info = merge_info)

    }else{

      result <- list(ASM_NAME = ASM_names[ind_ASM],
                     Iso_Num = nIsoforms_ind,
                     Exon_Num = nExons[ind_ASM],
                     isof_incl_unconstrained_g1 = isof_incl_u1,
                     variance_unconstrained_g1 = var_g1_u,
                     num_iters_unconstrained = u.iters,
                     param_unconstrained_g1 = alpha.u[1:nIsoforms_ind],
                     isoform_index = redundantTag,
                     merge_info = merge_info)

    }

    result

  }

  ## Close the clusters
  stopCluster(cl)

  ## Save all output to a list
  if(n_ASM == 1 && num_groups == 2){

    ASM_NAME.RES                  <- ASM_names
    Iso_Num.RES                   <- results$Iso_Num
    Exon_Num.RES                  <- nExons
    total_read_count_g1.RES       <- as.numeric(unlist(lapply(1:n_ASM, function(x) sum(nReads1[[x]]))))
    total_read_count_g2.RES       <- as.numeric(unlist(lapply(1:n_ASM, function(x) sum(nReads2[[x]]))))
    PValue.RES                    <- results$Pvalue
    testStat.RES                  <- results$testStat
    isof_incl_unconstr_g1.RES     <- results$isof_incl_unconstrained_g1
    isof_incl_unconstr_g2.RES     <- results$isof_incl_unconstrained_g2
    isof_incl_constr.RES          <- results$isof_incl_constrained
    variance_unconstrained_g1.RES <- results$variance_unconstrained_g1
    variance_unconstrained_g2.RES <- results$variance_unconstrained_g2
    variance_constrained.RES      <- results$variance_constrained
    num_iters_unconstrained.RES   <- results$num_iters_unconstrained
    num_iters_constrained.RES     <- results$num_iters_constrained
    param_unconstrained_g1.RES    <- results$param_unconstrained_g1
    param_unconstrained_g2.RES    <- results$param_unconstrained_g2
    param_constrained.RES         <- results$param_constrained
    isoform_pvals.RES             <- results$isoform_pvals
    isoform_index.RES             <- results$isoform_index
    merge_info.RES                <- results$merge_info

  }else if(n_ASM == 1 && num_groups == 1){

    ASM_NAME.RES                  <- ASM_names
    Iso_Num.RES                   <- results$Iso_Num
    Exon_Num.RES                  <- nExons
    total_read_count_g1.RES       <- as.numeric(unlist(lapply(1:n_ASM, function(x) sum(nReads1[[x]]))))
    isof_incl_unconstr_g1.RES     <- results$isof_incl_unconstrained_g1
    variance_unconstrained_g1.RES <- results$variance_unconstrained_g1
    num_iters_unconstrained.RES   <- results$num_iters_unconstrained
    param_unconstrained_g1.RES    <- results$param_unconstrained_g1
    isoform_index.RES             <- results$isoform_index
    merge_info.RES                <- results$merge_info

  }else if(num_groups == 2){

    ASM_NAME.RES                  <- ASM_names
    Iso_Num.RES                   <- results[2,]
    Exon_Num.RES                  <- nExons
    total_read_count_g1.RES       <- as.numeric(unlist(lapply(1:n_ASM, function(x) sum(nReads1[[x]]))))
    total_read_count_g2.RES       <- as.numeric(unlist(lapply(1:n_ASM, function(x) sum(nReads2[[x]]))))
    PValue.RES                    <- as.numeric(unlist(results[4,]))
    testStat.RES                  <- as.numeric(unlist(results[5,]))
    isof_incl_unconstr_g1.RES     <- results[6,]
    isof_incl_unconstr_g2.RES     <- results[7,]
    isof_incl_constr.RES          <- results[8,]
    variance_unconstrained_g1.RES <- results[9,]
    variance_unconstrained_g2.RES <- results[10,]
    variance_constrained.RES      <- results[11,]
    num_iters_unconstrained.RES   <- as.numeric(unlist(results[12,]))
    num_iters_constrained.RES     <- as.numeric(unlist(results[13,]))
    param_unconstrained_g1.RES    <- results[14,]
    param_unconstrained_g2.RES    <- results[15,]
    param_constrained.RES         <- results[16,]
    isoform_pvals.RES             <- results[17,]
    isoform_index.RES             <- results[18,]
    merge_info.RES                <- results[19,]

  }else{

    ASM_NAME.RES                  <- ASM_names
    Iso_Num.RES                   <- results[2,]
    Exon_Num.RES                  <- nExons
    total_read_count_g1.RES       <- as.numeric(unlist(lapply(1:n_ASM, function(x) sum(nReads1[[x]]))))
    isof_incl_unconstr_g1.RES     <- results[4,]
    variance_unconstrained_g1.RES <- results[5,]
    num_iters_unconstrained.RES   <- as.numeric(unlist(results[6,]))
    param_unconstrained_g1.RES    <- results[7,]
    isoform_index.RES             <- results[8,]
    merge_info.RES                <- results[9,]

  }

  ## Different results for one and two sample versions
  if(num_groups == 1){

    final_result <- list(ASM_name = ASM_NAME.RES,
                         total_isoforms = as.vector(unlist(Iso_Num.RES)),
                         total_exons = Exon_Num.RES,
                         total_read_count = total_read_count_g1.RES,
                         isoform_inclusion = sapply(1:n_ASM, function(x) paste(isof_incl_unconstr_g1.RES[[x]], collapse = ',')),
                         variance = sapply(1:n_ASM, function(x) paste(variance_unconstrained_g1.RES[[x]], collapse = ',')),
                         dirichlet_parameter = sapply(1:n_ASM, function(x) paste(param_unconstrained_g1.RES[[x]], collapse = ',')),
                         isoform_index = sapply(1:n_ASM, function(x) paste(isoform_index.RES[[x]], collapse = ',')),
                         merge_info = sapply(1:n_ASM, function(x) paste(merge_info.RES[[x]], collapse = ',')))

  }else{

    final_result <- list(ASM_name = ASM_NAME.RES,
                         total_isoforms = as.vector(unlist(Iso_Num.RES)),
                         total_exons = Exon_Num.RES,
                         total_read_count_group_1 = total_read_count_g1.RES,
                         total_read_count_group_2 = total_read_count_g2.RES,
                         p_value = PValue.RES,
                         test_statistic = testStat.RES,
                         isoform_inclusion_group_1 = sapply(1:n_ASM, function(x) paste(isof_incl_unconstr_g1.RES[[x]], collapse = ',')),
                         isoform_inclusion_group_2 = sapply(1:n_ASM, function(x) paste(isof_incl_unconstr_g2.RES[[x]], collapse = ',')),
                         isoform_inclusion_constrained = sapply(1:n_ASM, function(x) paste(isof_incl_constr.RES[[x]], collapse = ',')),
                         variance_group_1 = sapply(1:n_ASM, function(x) paste(variance_unconstrained_g1.RES[[x]], collapse = ',')),
                         variance_group_2 = sapply(1:n_ASM, function(x) paste(variance_unconstrained_g2.RES[[x]], collapse = ',')),
                         variance_constrained = sapply(1:n_ASM, function(x) paste(variance_constrained.RES[[x]], collapse = ',')),
                         dirichlet_parameter_group_1 = sapply(1:n_ASM, function(x) paste(param_unconstrained_g1.RES[[x]], collapse = ',')),
                         dirichlet_parameter_group_2 = sapply(1:n_ASM, function(x) paste(param_unconstrained_g2.RES[[x]], collapse = ',')),
                         dirichlet_parameter_constrained = sapply(1:n_ASM, function(x) paste(param_constrained.RES[[x]], collapse = ',')),
                         paired_isoform_pvalues = sapply(1:n_ASM, function(x) paste(isoform_pvals.RES[[x]], collapse = ',')),
                         isoform_index = sapply(1:n_ASM, function(x) paste(isoform_index.RES[[x]], collapse = ',')),
                         merge_info = sapply(1:n_ASM, function(x) paste(merge_info.RES[[x]], collapse = ',')))

  }

  ####################################################
  ## Write all output to a .txt file called outfile ##
  ####################################################

  sink(outfile, append = FALSE)
  cat(names(final_result), '\n')
  sink()
  for(ind_ASM in 1:n_ASM){
    result_ind <- sapply(final_result, function(x) x[ind_ASM])
    if(is.na(result_ind[2]))
      result_ind[2] <- nIsoforms[ind_ASM]
    sink(outfile, append = TRUE)
    cat(result_ind, '\n')
    sink()
  }

  ## Return a list with all of the results
  final_result

}

